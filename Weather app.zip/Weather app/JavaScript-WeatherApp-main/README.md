# JavaScript-WeatherApp
## Weather App with Vanilla JavaScript
I used API keys from this [link](https://openweathermap.org/)

https://reeyhanyilmaz.github.io/JavaScript-WeatherApp/


![app](assets/weatherApp.png) ![app](assets/weatherApp2.png)
